package org.redmart.test.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class SpreadSheetServiceTest {

	private static String[] args = null;
	private List<String> expectedAns = null;

	@Test
	public void testCalcSpreadsheetGivenSample() {
		args = new String[] { "3 2", "A2", "4 5 *", "A1", "A1 B2 / 2 +", "3", "39 B1 B2 * /" };
		expectedAns = new ArrayList<>();
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("8.66667");
		expectedAns.add("3.00000");
		expectedAns.add("1.50000");

		Map<String, String> results = new SpreadSheetService().calculateSpreadSheet(args);
		assertValues(results);
	}

	private void assertValues(Map<String, String> results) {
		Iterator<String> itr = results.values().iterator();
		for (int i = 0; i < results.values().size(); i++) {
			Assert.assertEquals(expectedAns.get(i), String.format("%.5f", Double.valueOf(itr.next())));
		}
	}

	@Test
	public void testCalcSpreadsheetAlterVal() {
		args = new String[] { "3 2", "A2", "4 5 *", "A1", "A1 B2 / 2 +", "B3", "39 2 2 * /" };
		expectedAns = new ArrayList<>();
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("4.05128");
		expectedAns.add("9.75000");
		expectedAns.add("9.75000");

		Map<String, String> results = new SpreadSheetService().calculateSpreadSheet(args);
		assertValues(results);
	}

	@Test
	public void testCalcSpreadsheetCyclic() {
		args = new String[] { "4 2", "A2", "4 5 *", "A1 A4 /", "B1", "A1 B2 / 2 +", "3", "39 B1 B2 * /", "5 2 *" };
		expectedAns = new ArrayList<>();
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("2.30769");
		expectedAns.add("8.66667");
		expectedAns.add("8.66667");
		expectedAns.add("3.00000");
		expectedAns.add("1.50000");
		expectedAns.add("10.00000");
		Map<String, String> results = new SpreadSheetService().calculateSpreadSheet(args);
		assertValues(results);
	}

	@Test
	public void testCalcSpreadsheetWith3Rows() {
		args = new String[] { "4 3", "A2", "4 5 *", "A1 A4 /", "B1", "A1 B2 / 2 +", "3", "39 B1 B2 * /", "5 2 *",
				"B1 C3 / 2 +", "5", "39 B1 B2 * /", "C3 2 *" };
		expectedAns = new ArrayList<>();
		expectedAns.add("20.00000");
		expectedAns.add("20.00000");
		expectedAns.add("2.30769");
		expectedAns.add("8.66667");
		expectedAns.add("8.66667");
		expectedAns.add("3.00000");
		expectedAns.add("1.50000");
		expectedAns.add("10.00000");
		expectedAns.add("7.77778");
		expectedAns.add("5.00000");
		expectedAns.add("1.50000");
		expectedAns.add("3.00000");
		Map<String, String> results = new SpreadSheetService().calculateSpreadSheet(args);
		assertValues(results);
	}
}
