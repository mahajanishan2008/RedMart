package org.redmart.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.redmart.test.service.SpreadSheetService;

public class Spreadsheet {

	public static void main(String[] args) {
		SpreadSheetService spreadSheetSvc = new SpreadSheetService();
		args = readFileArgs();
		System.out.println(args[0]);
		try {
			Map<String, String> calculateSpreadSheet = spreadSheetSvc.calculateSpreadSheet(args);
			calculateSpreadSheet.entrySet()
					.forEach(result -> System.out.println(String.format("%.5f", Double.valueOf(result.getValue()))));
		} catch (Exception e) {
			System.err.println("Some exception happened." + e.getMessage());
			System.exit(1);
		}
	}

	// Run exe jar as java -jar spreadsheet-calculator-1.0-SNAPSHOT . Attached is spreadsheet.txt for samples
	// Need to provide data to main function as path to the file e.g spreadsheet.txt
	// e.g C:\\Users\\mishan\\Documents\\sample
	// projects\\spreadsheet_calculator\\spreadsheet.txt
	
	private static String[] readFileArgs() {
		List<String> readAllLines = new ArrayList<>();
		String path = "";
		try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			System.out.println("Enter the file path and press enter : ");
			System.out.println("E.g 'C:\\Users\\mishan\\Documents\\sample projects\\spreadsheet_calculator' : ");
			path = br.readLine();
			readAllLines = Files.readAllLines(Paths.get(path));

		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		return readAllLines.toArray(new String[readAllLines.size()]);
	}

}
