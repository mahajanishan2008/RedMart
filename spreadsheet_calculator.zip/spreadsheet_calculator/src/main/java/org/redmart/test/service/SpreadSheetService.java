package org.redmart.test.service;

import java.util.LinkedHashMap;
import java.util.Map;

import org.redmart.test.util.PostFixCalc;

public class SpreadSheetService {

	private static final String REGEX = "^(?![0-9]*$)[a-zA-Z0-9]+$";
	private static final String REGEX_ATLEAST_ONESTRING = ".*[a-zA-Z]+.*";

	public Map<String, String> calculateSpreadSheet(String[] args) {
		int rows = Integer.valueOf(args[0].split(" ")[1]);
		int cols = Integer.valueOf(args[0].split(" ")[0]);
		if (rows > 26) {
			System.out.println("There could not be more than 26 rows.Exiting program");
			System.exit(1);

		}
		Map<String, String> spreadSheetMap = new LinkedHashMap<>();
		populateCells(args, rows, cols, spreadSheetMap);

		/**
		 * updating the map values after postfix calc.
		 */
		for (String key : spreadSheetMap.keySet()) {
			calculateAndUpdateMap(spreadSheetMap, key);
		}
		return spreadSheetMap;

	}

	private void calculateAndUpdateMap(Map<String, String> spreadSheetMap, String key) {
		String val = spreadSheetMap.get(key);
		String[] exp = val.split(" ");
		populateMap(spreadSheetMap, key, val, exp);
		/**
		 * while expression is not fully compose of digits and operators, revolve
		 * around.
		 */
		while (spreadSheetMap.get(key).matches(REGEX_ATLEAST_ONESTRING)) {
			populateMap(spreadSheetMap, key, spreadSheetMap.get(key), spreadSheetMap.get(key).split(" "));
		}
		spreadSheetMap.put(key, PostFixCalc.postfixOperation(spreadSheetMap.get(key)));
	}

	private void populateCells(String[] args, int rows, int cols, Map<String, String> spreadSheetMap) {
		for (int row = 0; row < rows; row++) {
			for (int col = 1; col <= cols; col++) {
				spreadSheetMap.put(getCharValue(row + 10) + (col), args[spreadSheetMap.size() + 1]);
			}
		}
	}

	private void populateMap(Map<String, String> spreadSheetMap, String key, String val, String[] exp) {
		for (String split : exp) {
			if (split.matches(REGEX)) {
				val = val.replace(split, spreadSheetMap.get(split));
				checkIfCircularDependency(key, val);
				spreadSheetMap.put(key, val);
			}
		}
	}

	private void checkIfCircularDependency(String key, String val) {
		if (val.contains(key)) {
			throw new RuntimeException(
					"There is circular dependency.Exiting the system. At Key = " + key + " and value: " + val);
		}
	}

	private String getCharValue(int i) {
		char forDigit = Character.forDigit(i, 16);
		return String.valueOf(forDigit).toUpperCase();
	}

}
