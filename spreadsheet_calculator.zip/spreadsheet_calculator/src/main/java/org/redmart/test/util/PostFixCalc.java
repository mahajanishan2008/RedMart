package org.redmart.test.util;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;
import java.util.stream.Collectors;

public class PostFixCalc {
	private static final String REGEX_FLOAT = "[+-]?([0-9]*[.])?[0-9]+";

	public static String postfixOperation(String str) {
		if (!str.matches(REGEX_FLOAT)) {
			List<String> split = Arrays.stream(str.split(" ")).collect(Collectors.toList());
			Stack<Double> stack = new Stack<>();

			for (String s : split) {
				if (s.matches(REGEX_FLOAT)) {
					stack.push(Double.valueOf(s));
				} else {
					Double i = stack.pop();
					Double j = stack.pop();
					switch (s) {

					case "*":
						stack.push(i * j);
						break;
					case "+":
						stack.push(i + j);
						break;
					case "-":
						stack.push(i - j);
						break;
					case "/":
						stack.push(j / i);
						break;
					}
				}
			}
			return String.valueOf(String.format("%.5f", stack.pop()));
		}
		return String.valueOf(String.format("%.5f", Double.valueOf(str)));
	}
}
